package PVE::QemuServer::ThunderstormTS;

use strict;
use warnings;

use Exporter 'import';
use PVE::Tools qw(run_command);

our @EXPORT_OK = qw(fifo_paths start stop);

my $helper = '/usr/local/bin/is1ts';
my $ffmpeg = '/usr/bin/ffmpeg';

sub fifo_paths {
    my ($vmid) = @_;
    die "invalid VM ID for Thunderstorm TS\n" if $vmid !~ /^\d+$/;
    my $base = "/run/qemu-server/$vmid.virtsc-ts";
    return {
        video => "$base-video",
        audio => "$base-audio",
        output => "$base-output",
    };
}

my sub unit_name {
    my ($vmid, $direction) = @_;
    return "virtsc-ts-$direction-$vmid.service";
}

my sub create_fifo {
    my ($path) = @_;
    die "refusing to replace non-FIFO Thunderstorm path '$path'\n" if -e $path && !-p $path;
    unlink $path or die "cannot remove stale Thunderstorm FIFO '$path': $!\n" if -p $path;
    run_command(['/usr/bin/mkfifo', '-m', '0600', $path]);
}

sub stop {
    my ($vmid) = @_;
    my $paths = fifo_paths($vmid);
    for my $direction (qw(input output)) {
        eval {
            run_command(
                ['/bin/systemctl', 'stop', unit_name($vmid, $direction)],
                outfunc => sub { }, errfunc => sub { }, timeout => 10,
            );
        };
    }
    for my $path (values %$paths) {
        unlink $path or warn "cannot remove Thunderstorm FIFO '$path': $!\n" if -p $path;
    }
}

my sub wait_for_unit_release {
    my ($unit) = @_;
    for (1 .. 25) {
        my $state = '';
        run_command(
            ['/bin/systemctl', 'show', '--property=LoadState', '--value', $unit],
            outfunc => sub { $state .= $_[0] }, timeout => 5,
        );
        return if $state =~ /^not-found\s*$/;
        select undef, undef, undef, 0.2;
    }
    die "Thunderstorm TS service '$unit' is still loaded after stop; inspect it with systemctl status $unit\n";
}

my sub launch {
    my ($vmid, $direction, $restart, @program) = @_;
    my $unit = unit_name($vmid, $direction);
    wait_for_unit_release($unit);
    run_command([
        '/usr/bin/systemd-run', '--quiet', '--collect',
        '--unit=' . $unit,
        "--property=Restart=$restart", '--property=RestartSec=2s',
        '--', @program,
    ], timeout => 15);
}

sub start {
    my ($vmid, $options) = @_;
    my $source = $options->{'ts-input'};
    my $target = $options->{'ts-output'};
    return if !$source && !$target;
    die "Thunderstorm TS requires /usr/bin/ffmpeg (install the ffmpeg package)\n"
        if !-x $ffmpeg;
    die "Thunderstorm TS output requires /usr/local/bin/is1ts (see the install guide)\n"
        if $target && !-x $helper;

    my $paths = fifo_paths($vmid);
    stop($vmid);
    eval {
        if ($source) {
            create_fifo($paths->{video});
            my $with_audio = $options->{'ts-input-audio'} // 1;
            create_fifo($paths->{audio}) if $with_audio;
            my @cmd = (
                $ffmpeg, '-hide_banner', '-loglevel', 'warning', '-nostdin',
                '-readrate', '1', '-i', $source,
                '-map', '0:v:0', '-an', '-vf', 'fps=30000/1001,scale=720:480,vflip',
                '-pix_fmt', 'yuyv422',
                '-f', 'rawvideo', '-y', $paths->{video},
            );
            push @cmd, (
                '-map', '0:a:0', '-vn', '-ac', '2', '-ar', '48000',
                '-c:a', 'pcm_s32le', '-f', 's32le', '-y', $paths->{audio},
            ) if $with_audio;
            launch($vmid, 'input', 'on-failure', @cmd);
        }
        if ($target) {
            create_fifo($paths->{output});
            my $restart = $target =~ m{^[a-z][a-z0-9+.-]*://}i ? 'on-failure' : 'no';
            launch($vmid, 'output', $restart,
                $helper, '-r', '-i', $paths->{output}, $target);
        }
    };
    if (my $err = $@) {
        stop($vmid);
        die $err;
    }
}

1;
