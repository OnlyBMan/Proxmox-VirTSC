package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '9.2.20+virtsc2';
}

sub release {
    return '9.2';
}

sub repoid {
    return '';
}

sub version_text {
    return '9.2.20+virtsc2/';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '9.2.20+virtsc2',
	'release' => '9.2',
	'repoid' => '',
    }
}

1;
